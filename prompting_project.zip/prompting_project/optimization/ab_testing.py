import random

def ab_test(prompts, models):
    results = []
    for prompt in prompts:
        for model in models:
            score = random.uniform(0,1)
            results.append({'prompt': prompt, 'model': model, 'score': score})
    return results

if __name__ == "__main__":
    test_prompts = ["Prompt A", "Prompt B"]
    test_models = ["GPT-4", "Claude"]
    print(ab_test(test_prompts, test_models))
