import csv

criteria = [
    "Clarity of instruction",
    "Context framing",
    "Role grounding",
    "Temperature tolerance",
    "Manipulation resistance",
    "Output format accuracy",
    "Safety disclaimer",
    "Unambiguous task criteria",
    "Integration ergonomics",
    "Compliance alignment",
    "Length/scoping",
    "Custom"
]

def evaluate(prompt, scores):
    assert len(scores) == len(criteria)
    total = sum(scores)
    print(f"Prompt Score: {total}/{2 * len(criteria)}")
    return total

# Example usage
if __name__ == "__main__":
    prompt_example = "Act as an investor."
    score_example = [2,2,2,2,1,2,2,2,2,1,2,1]
    evaluate(prompt_example, score_example)
