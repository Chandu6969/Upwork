import streamlit as st
import pandas as pd

st.title("Prompt Effectiveness Dashboard")

results = pd.read_csv("../data/evaluation_results.csv")
st.bar_chart(results[["Prompt Version", "Clarity Score", "Jailbreak Score"]])
