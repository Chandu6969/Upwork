def load_experiment_data(path):
    import pandas as pd
    return pd.read_csv(path)
