import json

def validate_json_structure(response):
    try:
        data = json.loads(response)
        assert 'summary' in data and 'risks' in data and 'recommendations' in data
        return True
    except Exception:
        return False
