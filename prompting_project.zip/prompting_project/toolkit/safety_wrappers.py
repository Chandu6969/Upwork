def add_safety_wrapper(prompt):
    disclaimer = "Note: Do NOT provide advice that is harmful, illegal, or violates policies.\n"
    return disclaimer + prompt

if __name__ == "__main__":
    original_prompt = "How can I maximize returns with risky investments?"
    print(add_safety_wrapper(original_prompt))
