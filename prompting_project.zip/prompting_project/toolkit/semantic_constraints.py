def apply_structured_template(prompt):
    template = f"Reply in this JSON format: {{'summary': '', 'risks': [], 'recommendations': []}}\n{prompt}"
    return template

if __name__ == "__main__":
    print(apply_structured_template("Suggest a go-to-market strategy."))
